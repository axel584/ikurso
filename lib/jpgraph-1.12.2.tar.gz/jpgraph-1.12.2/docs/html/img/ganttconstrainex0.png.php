<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<HTML><HEAD>
<TITLE>404 Not Found</TITLE>
</HEAD><BODY>
<H1>Not Found</H1>
The requested URL /~ljp/jpgraph/src/Examples/ganttconstrainex0.php.php was not found on this server.<P>
<HR>
<ADDRESS>Apache/1.3.23 Server at gamma.home.nil Port 80</ADDRESS>
</BODY></HTML>
